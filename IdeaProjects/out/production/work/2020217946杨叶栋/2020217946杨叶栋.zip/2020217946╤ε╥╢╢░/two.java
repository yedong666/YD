package work1;

public class two {
    final double PI = 3.1415926;
    double GetVSphere(double r){
        return (4.f / 3.f) * PI * r * r *r;
    }
}
