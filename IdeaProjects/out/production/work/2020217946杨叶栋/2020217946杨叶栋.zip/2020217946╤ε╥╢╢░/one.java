package work1;

public class one {
    double turnDegreeType(double CDegree){
        return (9.f / 5.f) * CDegree + 32.f;
    };
}
